package db_assignment2;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import sun.security.pkcs11.wrapper.Constants;

class bitSlice 
{
     static HashMap<Integer,String> bitSliceHash=new HashMap<>();
    public void implement() throws IOException
    {       
        String file;
        file = "C:\\Users\\Mamta Sharma\\Documents\\NetBeansProjects\\DB_Assignment2\\src\\db_assignment2\\BitSliceIndex\\file1.txt";
        BufferedWriter brSlice=new BufferedWriter(new FileWriter(file));
        int BlockNo=-1;
        ArrayList<Record> all_RecordsVal;
        int size=DB_Assignment2.records.size();
        all_RecordsVal=DB_Assignment2.records;
        System.out.println(size);
        for(int i=0;i<size;i++)
        {
            int arr[];
            arr=all_RecordsVal.get(i).arr;
            int record=all_RecordsVal.get(i).amount;
            int temp=record;
            int index=11;
            while(temp!=0)
            {   
                int bit=temp%2;
                temp=temp/2;
                arr[index]=bit;
                index--;
            }
            for(int j=index;j>=0;j--)
            {
               arr[j]=0;
            }
            
        }
       
        all_RecordsVal.stream().map((all_RecordsVal1) -> {
            //System.out.print(all_RecordsVal1.amount+"   ");
            return all_RecordsVal1;
        }).map((all_RecordsVal1) -> {
            //for(int in:all_RecordsVal1.arr)
                //System.out.print(in);
            return all_RecordsVal1;
        }).forEachOrdered((_item) -> {
            //System.out.println("");
        });
       for(int in=0;in<12;in++)
       {
           int B[]=new int[all_RecordsVal.size()];
        for(int i=0;i<all_RecordsVal.size();i++)
        {
            B[i]=all_RecordsVal.get(i).arr[in];
        }
       
         for(int bit=0;bit<B.length;bit++)
         {
             if(bit%10==0)// change 10 to 32000
             {
                 brSlice.close();
                 BlockNo++;
                 file = "C:\\Users\\Mamta Sharma\\Documents\\NetBeansProjects\\DB_Assignment2\\src\\db_assignment2\\BitSliceIndex\\file"+BlockNo+".txt";
                 brSlice=new BufferedWriter(new FileWriter(file));
                 if(bit==0)
                     bitSliceHash.put(11-in, file);
             }
             String s=Integer.toString(B[bit]);
             brSlice.write(s);
             brSlice.write(Constants.NEWLINE);
         }
         brSlice.close();
       }
       /*Set <Integer> set=bitSliceHash.keySet();
       Iterator<Integer> it=set.iterator();
       while(it.hasNext())
       {
           int b=it.next();
           String s=bitSliceHash.get(b);
           //System.out.println("BitSlice No"+b+" has first block address as:"+s);
       }*/
    }
    
}
