package db_assignment2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import sun.security.pkcs11.wrapper.Constants;

class bitVector 
{
    static HashMap<Integer,String> UniqueValuesHashBit=new HashMap<>();
    static HashMap<Integer,String> UniqueRowIdHash=new HashMap<>();
    public void implement() throws FileNotFoundException, IOException
    {
       //create the bit vector array for all unique values 
        UniqueValuesHashBit=DB_Assignment2.bitArrayHash;
        Set<Integer> set=UniqueValuesHashBit.keySet();
        Iterator<Integer> iterator= set.iterator();
        String bitArrayFile="C:\\Users\\Mamta Sharma\\Documents\\NetBeansProjects\\DB_Assignment2\\src\\db_assignment2\\BitArrayBlocks\\file1.txt";
        String rowIdFile="C:\\Users\\Mamta Sharma\\Documents\\NetBeansProjects\\DB_Assignment2\\src\\db_assignment2\\RowIDBlocks\\file1.txt";
        BufferedWriter brBit=new BufferedWriter(new FileWriter(bitArrayFile));
        BufferedWriter brRowID=new BufferedWriter(new FileWriter(bitArrayFile));
        int noOfBlocks =(int)Math.ceil((double)(DB_Assignment2.n)/(double)(DB_Assignment2.blockSize));
        int noOfBlocksBitArray=(int)Math.ceil((double)DB_Assignment2.n/(double)32000);
        int bitArrayBlockNumber=0;
        int rowIdBlockNumber=0;
        while(iterator.hasNext())
        {
            int amount=iterator.next();
            //System.out.println(amount);
            ArrayList <Integer> rowIDs=new ArrayList<>();
            int bitArray[]=new int[DB_Assignment2.n];
            int rowNO=0;
            for(int blockNo=1;blockNo<=noOfBlocks;blockNo++)
            {
               String file = "C:\\Users\\Mamta Sharma\\Documents\\NetBeansProjects\\DB_Assignment2\\src\\db_assignment2\\Blocks\\file"+blockNo+".txt";
                try (BufferedReader bf = new BufferedReader(new FileReader(file))) {
                    String row;
                    while((row=bf.readLine())!=null)
                    {
                        //System.out.println(row);
                        String[] arr=row.split("   ");
                        if(arr.length!=3)
                            continue;
                        //System.out.println(arr.length);
                        int tranVal=Integer.parseInt(arr[1]);
                        if(amount==tranVal)
                        {
                            bitArray[rowNO]=1;
                            rowIDs.add(rowNO+1);
                        }
                        rowNO++;
                    }}
            }
            //for(int a:bitArray)System.out.println(a);
            for(int index=0;index<bitArray.length;index++)
            {
                if(index%10==0 )     //change the value 10 to 32000 after testing(it is number of bits that can be stored in a block)
                {
                    bitArrayBlockNumber++;
                    brBit.close();
                    bitArrayFile="C:\\Users\\Mamta Sharma\\Documents\\NetBeansProjects\\DB_Assignment2\\src\\db_assignment2\\BitArrayBlocks\\file"+bitArrayBlockNumber+".txt";
                    brBit=new BufferedWriter(new FileWriter(bitArrayFile));
                }
                int v=bitArray[index];
                if(v==1)
                brBit.write("1");
                else if(v==0)
                    brBit.write("0");
                brBit.write(Constants.NEWLINE);
                if(index==0)
                {
                    //store first block entry in the hashmap value
                    UniqueValuesHashBit.put(amount, bitArrayFile);
                }
            }
            brBit.close();
            
            for(int i=0;i<rowIDs.size();i++)
            {
                if(i%5==0 )     //change the value 5 to 1000 after testing(it is number of rowIDs that can be stored in a block)
                {
                    rowIdBlockNumber++;
                    brRowID.close();
                    rowIdFile="C:\\Users\\Mamta Sharma\\Documents\\NetBeansProjects\\DB_Assignment2\\src\\db_assignment2\\RowIDBlocks\\file"+rowIdBlockNumber+".txt";
                    brRowID=new BufferedWriter(new FileWriter(rowIdFile));
                }
                int v=rowIDs.get(i);
                String s=Integer.toString(v);
                brRowID.write(s);
                brRowID.write(Constants.NEWLINE);
                if(i==0)
                {
                    //store first block entry in the hashmap value
                    UniqueRowIdHash.put(amount, rowIdFile);
                }
                brRowID.write("end");
            }
            brRowID.close();
        }
       /* Set<Integer> s=UniqueValuesHashBit.keySet();
        Iterator<Integer> i=s.iterator();
        while(i.hasNext())
        {
            int key=i.next();
            String value=UniqueValuesHashBit.get(key);
            //System.out.println(""+key+"  "+value);
        }*/
    }
    
}
