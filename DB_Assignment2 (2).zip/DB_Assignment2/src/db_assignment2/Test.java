/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db_assignment2;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Mamta Sharma
 */
public class Test 
{
    String file="C:\\Users\\Mamta Sharma\\Documents\\NetBeansProjects\\DB_Assignment2\\src\\db_assignment2\\BitArrayBlocks\\file1.txt";
    Scanner sc=new Scanner(file);
    
    ArrayList<Integer> arr=new ArrayList<>();
    
    //int startBlockNo=
}
