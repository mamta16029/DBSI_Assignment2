package db_assignment2;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

class ExperimentsClass
{
    public void Experiments() throws IOException
    {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter No of Ones that you want in BF but these should be less than "+DB_Assignment2.n);
        int ones=s.nextInt();//change this value to 100000
        
        int Bf[];
        Bf=generateBF(ones);
        
        Block_Sum obj1;
        obj1=noIndexScan(Bf);
        System.out.println("Blocks count are: "+obj1.BlockCount+" Sum is :"+obj1.Sum);
        
        Block_Sum obj2;
        obj2=bitIndexArrayScan(Bf);
        System.out.println("Blocks count are: "+obj2.BlockCount+" Sum is :"+obj2.Sum);
        
        Block_Sum obj3=new Block_Sum();
        obj3=rowIDSacn(Bf);
        System.out.println("Blocks count are: "+obj3.BlockCount+" Sum is :"+obj3.Sum);
        
        Block_Sum obj4=new Block_Sum();
        obj4=bitSliceScan(Bf);
        System.out.println("Blocks count are: "+obj4.BlockCount+" Sum is :"+obj4.Sum);
    }

    private Block_Sum noIndexScan(int[] Bf) throws FileNotFoundException, IOException 
    {
        int countBlock=1;
        int Sum=0;
        int rowNo=0;
        String file="C:\\Users\\Mamta Sharma\\Documents\\NetBeansProjects\\DB_Assignment2\\src\\db_assignment2\\Blocks\\file1.txt";
        BufferedReader br=new BufferedReader(new FileReader(file));
        //int noOfBlocks=(int) Math.ceil((double)DB_Assignment2.n/(double)DB_Assignment2.blockSize);
        
        String row;
        while((row=br.readLine())!=null)
        {
           String arr[]=row.split("   ");
           if(arr.length==3)
           {
               int val=Integer.parseInt(arr[1]);
               if(Bf[rowNo]==1)
               {
                   Sum+=val;
               }
               rowNo++;
           }
            
           else
           {
               file=arr[0];
               br.close();
               br=new BufferedReader(new FileReader(file));
               countBlock++;
           }
        }
        br.close();
        Block_Sum obj=new Block_Sum(Sum, countBlock);
        return obj;
    }

    private Block_Sum bitIndexArrayScan(int[] Bf) throws FileNotFoundException, IOException 
    {
        int countBlock=0;
        int Sum=0;
        int BlockNo=1;
        
        String file="C:\\Users\\Mamta Sharma\\Documents\\NetBeansProjects\\DB_Assignment2\\src\\db_assignment2\\BitArrayBlocks\\file"+BlockNo+".txt";
        BufferedReader bf=new BufferedReader(new FileReader(file));
        Set<Integer> set=bitVector.UniqueValuesHashBit.keySet();
        Iterator<Integer> iterator=set.iterator();
        while(iterator.hasNext())
        {
            int index=0;
            int val=iterator.next();
            int noOFBlocks=(int) Math.ceil((double)DB_Assignment2.n/(double)10);
            file=bitVector.UniqueValuesHashBit.get(val);
            int startBlockNo;
            String str = file;
            str = str.replaceAll("[^-?0-9]+", " "); 
            String st=Arrays.asList(str.trim().split(" ")).get(2);
            startBlockNo=Integer.parseInt(st);
            //System.out.println(startBlockNo);
            int[] bitVector=new int[DB_Assignment2.n];
            for(int block=startBlockNo;block<startBlockNo+noOFBlocks;block++)
            {
                countBlock++;
                file="C:\\Users\\Mamta Sharma\\Documents\\NetBeansProjects\\DB_Assignment2\\src\\db_assignment2\\BitArrayBlocks\\file"+block+".txt";
                bf=new BufferedReader(new FileReader(file));
                String str1;
                while((str1=bf.readLine())!=null)
                {
                    int bit=Integer.parseInt(str1);
                    bitVector[index]=bit;
                    index++;
                    
                }
            }
            //count number of ones in the bit Array after ANDing with BF
            //System.out.println("Size of bitVector read by Buffer:"+bitVector.length);
            //System.out.println("                      Size of Bf:"+Bf.length);
            //for(int i:bitVector)System.out.print(i);
            //System.out.println("");
            //for(int i:Bf)System.out.print(i);
            //System.out.println("");
            int count=0;
            for(int i=0;i<Bf.length;i++)
            {
                if(Bf[i]==bitVector[i] && Bf[i]==1)
                {
                    count++;
                }
            }
            Sum+=val*count;
            
        }
        
        
        Block_Sum obj=new Block_Sum(Sum, countBlock);
        return obj;
    }

    private Block_Sum rowIDSacn(int[] Bf) throws FileNotFoundException, IOException 
    {
        int countBlock=0;
        int Sum=0;
        int N=1;
        String file="C:\\Users\\Mamta Sharma\\Documents\\NetBeansProjects\\DB_Assignment2\\src\\db_assignment2\\RowIDBlocks\\file"+1+".txt";
        BufferedReader bf=new BufferedReader(new FileReader(file));
        Set<Integer> set=bitVector.UniqueRowIdHash.keySet();
        Iterator<Integer> iterator=set.iterator();
        while(iterator.hasNext())
        {
             int val=iterator.next();
             int lineNo=0;
             String firstBlockAdd=bitVector.UniqueRowIdHash.get(val);
             file=firstBlockAdd;
             String str = file;
             str = str.replaceAll("[^-?0-9]+", " "); 
             String st=Arrays.asList(str.trim().split(" ")).get(2);
             N=Integer.parseInt(st);//parse to find int value in string file 
             ArrayList<Integer> rows=new ArrayList<>();
             bf=new BufferedReader(new FileReader(file));
             countBlock++;
             String bit;
             while(!(bit=bf.readLine()).equalsIgnoreCase("end"))
             {
                 int rowNo=Integer.parseInt(bit);
                 lineNo++;
                 rows.add(rowNo);
                 
                 if(lineNo%5==0)//change this value to 5 to 1000
                 {
                     N++;
                     bf.close();
                     bf=new BufferedReader(new FileReader("C:\\Users\\Mamta Sharma\\Documents\\NetBeansProjects\\DB_Assignment2\\src\\db_assignment2\\RowIDBlocks\\file"+N+".txt"));
                     countBlock++;
                 }
             }
             bf.close();
             //System.out.print(val+" has rowID's as: ");
            //for(int i:rows){System.out.print(i+",");}
            //System.out.println(rows);
            for(int i=0;i<rows.size();i++)
            {
                int row=rows.get(i);
                if(Bf[row-1]==1)
                {
                    Sum+=val;
                }
            }
                       
            
        }
        
        Block_Sum obj=new Block_Sum(Sum, countBlock);
        return obj;
    }

    private Block_Sum bitSliceScan(int[] Bf) throws FileNotFoundException, IOException 
    {
        int countBlock=0;
        int Sum=0;
        
        int totalBlocks=(int) Math.ceil((double)DB_Assignment2.n/(double)10);   //replace this 10 with 32000 
        String file="C:\\Users\\Mamta Sharma\\Documents\\NetBeansProjects\\DB_Assignment2\\src\\db_assignment2\\BitSliceIndex\\file"+1+".txt";
        BufferedReader bf=new BufferedReader(new FileReader(file));
        Set<Integer> set=bitSlice.bitSliceHash.keySet();
        Iterator<Integer> iterator=set.iterator();
        while(iterator.hasNext())
        {
            int B=iterator.next();
            String fileName=bitSlice.bitSliceHash.get(B);
            file=fileName;
            int N=0;
            int startBlockNo;
            String str = fileName;
            str = str.replaceAll("[^-?0-9]+", " "); 
            String st=Arrays.asList(str.trim().split(" ")).get(2);
            startBlockNo=Integer.parseInt(st);
            //System.out.println(startBlockNo);
            int[] bitSliceVector=new int[DB_Assignment2.n];
             int index=0;
             for(int block=0;block<totalBlocks;block++)
             {
                 file="C:\\Users\\Mamta Sharma\\Documents\\NetBeansProjects\\DB_Assignment2\\src\\db_assignment2\\BitSliceIndex\\file"+startBlockNo+".txt";
                 bf=new BufferedReader(new FileReader(file));
                 countBlock++;
                 startBlockNo++;
                 String sb;
                 while((sb=bf.readLine())!=null)
                 {
                     int bit=Integer.parseInt(sb);
                     bitSliceVector[index]=bit;
                     index++;
                 }
                 bf.close();
             }
             bf.close();
             int c=0;
             for(int s:bitSliceVector){System.out.print(s);}
             System.out.println("");
             for(int i=0;i<Bf.length;i++)
             {
                 if(Bf[i]==bitSliceVector[i] && Bf[i]==1)
                 {
                    c++;
                 }
             }
             Sum+=(Math.pow(2, B))*c;
        
        }
        Block_Sum obj=new Block_Sum(Sum, countBlock);
        return obj;
    }

    //generate a BF with given number of ones 
    public int[] generateBF(int number)
    { 
		int[] result=new int[number];
		Set<Integer>used;
                used=new HashSet<Integer>();
		int bf[]=new int[DB_Assignment2.n];//stores BF
		Random rand=new Random();
		for(int i=0;i<number;i++){
			int newRandom;
			do{
				newRandom=rand.nextInt(DB_Assignment2.n);
				
			}while(used.contains(newRandom));
			
			result[i]=newRandom;
			used.add(newRandom);
			
		}
		
		for(int i=0;i<DB_Assignment2.n;i++){
			for(int j=0;j<number;j++){
				if(i==result[j]){
					bf[i]=1;
					break;
				}
				else 
					bf[i]=0;
			}
			
		}
                /*for(int a:bf)
                {System.out.print(a);}
                System.out.println("");*/
                return bf;
   }
   
}
class Block_Sum
{
  int Sum;
  int BlockCount;
  public Block_Sum(){}
  public Block_Sum(int sum,int count){Sum=sum;BlockCount=count;}
  public int getSum(){return Sum;}
  public int getBlockCount(){return BlockCount;}
}