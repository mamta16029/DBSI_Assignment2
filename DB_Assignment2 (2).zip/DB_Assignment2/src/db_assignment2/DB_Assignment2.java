package db_assignment2;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import static java.lang.System.exit;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;
import sun.security.pkcs11.wrapper.Constants;

public class DB_Assignment2 
{
    static ArrayList<Record> records=new ArrayList<Record>();
    static HashMap<Integer,String> bitArrayHash=new HashMap<Integer,String>();
   // static ArrayList<Integer> all_Records=new ArrayList<>();
    static int n;
    static int blockSize;
    public static void main(String[] args) throws IOException 
    {
        while(true)
        {
        System.out.println("Which part you want to implement? 1. Data Creation 2. Bit Vector 3.Bit Slice 4.Perform Experiment");
        System.out.println("Press any other key to Exit!!");
        Scanner s1=new Scanner(System.in);
        int s=s1.nextInt();
        switch(s)
        {
            case 1:
                System.out.println("Enter how many records do you want? ");
                Scanner sc=new Scanner(System.in);
                n=sc.nextInt();
                System.out.println("Enter Block size that you want? ");
                blockSize=sc.nextInt();
                createData(n,blockSize);
                break;
            case 2:
                bitVector bv=new bitVector();
                bv.implement();
                break;
            case 3:
                bitSlice bs=new bitSlice();
                bs.implement();
                break;
            case 4:
                ExperimentsClass exp=new ExperimentsClass();
                exp.Experiments();
                break;
            default:
                exit(0);
                break;
        }
        }

    }
//  print All records in file         

    /**
     *
     * @param n
     * @param blockSize
     * @throws IOException
     */
    public static void createData(int n,int blockSize) throws IOException
    {
        
        int bits=12;
        int count=1;
        int BlockSize_BitArray=32000/bits;
        int i;
        int bitArrayIndexBlocks=(int) Math.ceil((double)n/(double)BlockSize_BitArray);
        //System.out.println(bitArrayIndexBlocks);
        int bitCount=1;
        String bitFile="C:\\Users\\Mamta Sharma\\Documents\\NetBeansProjects\\DB_Assignment2\\src\\db_assignment2\\BitArrayBlocks\\file"+bitCount+".txt";
        String file = "C:\\Users\\Mamta Sharma\\Documents\\NetBeansProjects\\DB_Assignment2\\src\\db_assignment2\\Blocks\\file"+count+".txt";
        String FILENAME = "C:\\Users\\Mamta Sharma\\Documents\\NetBeansProjects\\DB_Assignment2\\src\\db_assignment2\\Dataset.txt";
        BufferedWriter bw1=new BufferedWriter(new FileWriter(file));
        BufferedWriter bitWriter=new BufferedWriter(new FileWriter(bitFile));
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILENAME))) {
            for(i=0;i<n;i++)
            {
                Random ran=new Random();
                int amount=ran.nextInt(2500)+1;
                if(!bitArrayHash.containsKey(amount))
                    bitArrayHash.put(amount,null);
              
                SecureRandom random = new SecureRandom();
                String name=new BigInteger(130, random).toString(32);
                name=(String) name.subSequence(1, 4);
                Record r=new Record(amount);
                records.add(r);
                String s;
                
                int iid=i+1;
                s=Integer.toString(iid);
                s=s.concat("   ");
                s=s.concat(Integer.toString(r.amount));
                s=s.concat("   ");
                s=s.concat(name);
                bw.write(s);
                
                bw.write(Constants.NEWLINE);
                if(i%blockSize==0 && i!=0 )
                {   //create a new block
                    file = "C:\\Users\\Mamta Sharma\\Documents\\NetBeansProjects\\DB_Assignment2\\src\\db_assignment2\\Blocks\\file"+count+".txt";
                    bw1=new BufferedWriter(new FileWriter(file));
                }
                bw1.write(s);
                bw1.write(Constants.NEWLINE);
               if(i==n-1 && i%blockSize!=blockSize-1)
                {
                    bw1.close();
                }
                if(i%blockSize==blockSize-1 )
                {
                    if(i!=n-1)
                        bw1.write("C:\\Users\\Mamta Sharma\\Documents\\NetBeansProjects\\DB_Assignment2\\src\\db_assignment2\\Blocks\\file"+(count+1)+".txt");
                    count++;
                    bw1.close();
                }
                      
            }
        }
       
    }
             
    }
    


class Record
{
    int amount;
    int arr[];
    public Record(){}
    public Record(int a)
    {
        amount=a;
        arr=new int[12];
    }
}
